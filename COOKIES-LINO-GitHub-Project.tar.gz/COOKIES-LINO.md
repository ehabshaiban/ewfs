# COOKIES LINO — تحويل صفحة HTML إلى مشروع Twilight/Salla

تم فصل واجهة COOKIES LINO من ملف HTML واحد إلى:

- `src/views/components/home/cookies-lino.twig` — واجهة الصفحة الرئيسية.
- `src/assets/styles/05-components/cookies-lino.scss` — نظام التصميم الخاص بلينو.
- `src/assets/js/cookies-lino.js` — البيانات والتفاعلات والسلة/المفضلة/البحث/الوضع الليلي/FAQ.
- `src/views/pages/index.twig` — يحمّل مكوّن لينو في الصفحة الرئيسية.
- `lino-static/` — نسخة HTML مستقلة للمعاينة المحلية دون Twig/Salla.

## ملاحظة
الصور في النسخة الأصلية تستخدم Unsplash، وبيانات المنتجات تجريبية. عند النشر على سلة استبدل بيانات `LINO_PRODUCTS` وروابط `LINO_ASSETS` بمصادر Twig/CDN سلة كما هو موضح في المصدر.
